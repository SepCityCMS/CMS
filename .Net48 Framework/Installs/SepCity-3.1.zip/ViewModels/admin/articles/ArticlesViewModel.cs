﻿namespace wwwroot.ViewModels.admin.articles
{
    public class ArticlesViewModel : wwwroot.ViewModels.MasterPageViewModel
    {

    }
}

