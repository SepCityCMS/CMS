function loadTxt() {
    document.getElementById("txtLang").innerHTML = "Confermi che vuoi eliminare questa cartella?";

    document.getElementById("btnClose").value = "chiudi";
    document.getElementById("btnDelete").value = "rimuovi";
}

function writeTitle() {
    document.write("<title>Elimina Cartella</title>");
}