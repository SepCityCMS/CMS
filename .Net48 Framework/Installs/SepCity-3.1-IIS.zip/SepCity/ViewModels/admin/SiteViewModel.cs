﻿namespace wwwroot.ViewModels.admin
{
    public class SiteViewModel : wwwroot.ViewModels.MasterPageViewModel
    {

    }
}

